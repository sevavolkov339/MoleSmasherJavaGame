package entity;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.KeyHandler;
import main.Sound;

public class Hummer extends Entity{
    GamePanel gp;
    KeyHandler keyH;

    private Sound smashSound;

    public Hummer(GamePanel gp, KeyHandler keyH) {
        this.gp = gp;
        this.keyH = keyH;

        setDefaultValues();
        getHummerImage();

        smashSound = new Sound();
        smashSound.loadAndPrepareClip("/Sounds/hit.wav");

    }
    public void setDefaultValues() {
        x = 300;
        y = 300;
        speed = 8;
        direction = "down";


    }

    public void getHummerImage() {
        try {

            up1 = ImageIO.read(getClass().getResourceAsStream("/hummer/HummerSmashL.png"));
            up2 = ImageIO.read(getClass().getResourceAsStream("/hummer/HummerSmashL.png"));
            down1 = ImageIO.read(getClass().getResourceAsStream("/hummer/HummerSmashR.png"));
            down2 = ImageIO.read(getClass().getResourceAsStream("/hummer/HummerSmashR.png"));
            left1 = ImageIO.read(getClass().getResourceAsStream("/hummer/HummerUpRL.png"));
            left2 = ImageIO.read(getClass().getResourceAsStream("/hummer/HummerUpRL.png"));
            right1 = ImageIO.read(getClass().getResourceAsStream("/hummer/HummerUpRL.png"));
            right2 = ImageIO.read(getClass().getResourceAsStream("/hummer/HummerUpRL.png"));

        }catch(IOException e) {
            e.printStackTrace();
        }
    }

    public void update() {


        //hummer move
        if(keyH.upPressed == true || keyH.downPressed == true ||
                keyH.leftPressed == true || keyH.rightPressed == true) {
            if(keyH.upPressed == true && keyH.spacePressed == false) {
                y = y - speed;
                direction = "left";
            }
            else if(keyH.downPressed == true && keyH.spacePressed == false) {
                y = y + speed;
                direction = "left";
            }

            if(keyH.leftPressed == true && keyH.spacePressed == false) {
                x = x - speed;
                direction = "left";
            }
            else if(keyH.rightPressed == true && keyH.spacePressed == false) {
                x = x + speed;
                direction = "right";
            }





            //hummer smash
            if(direction == "left" && keyH.spacePressed == true){
                direction = "up";
                smashSound.playLoadedClip();
            }
            else if(direction == "right" && keyH.spacePressed == true) {
                direction = "down";
                smashSound.playLoadedClip();
            }

            spriteCounter++;
            if(spriteCounter > 10) {
                if(spriteNum == 1) {
                    spriteNum = 2;
                }
                else if(spriteNum == 2) {
                    spriteNum = 1;
                }
                spriteCounter = 0;
            }

            hummerBackToNormalTimer++;

            if (hummerBackToNormalTimer > 20) {
                keyH.spacePressed = false;
                //speed = 10;
                hummerBackToNormalTimer = 0;
            }

        }

    }

    public void draw(Graphics2D g2) {
		/*
		g2.setColor(Color.white);
		g2.fillRect(x, y, gp.tileSize, gp.tileSize);
		*/

        BufferedImage image = null;

        switch(direction) {
            case "up":
                if(spriteNum == 1) {
                    image = up1;
                }
                if(spriteNum == 2) {
                    image = up2;
                }

                break;
            case "down":
                if(spriteNum == 1) {
                    image = down1;
                }
                if(spriteNum == 2) {
                    image = down2;
                }
                break;
            case "left":
                if(spriteNum == 1) {
                    image = left1;
                }
                if(spriteNum == 2) {
                    image = left2;
                }
                break;
            case "right":
                if(spriteNum == 1) {
                    image = right1;
                }
                if(spriteNum == 2) {
                    image = right2;
                }
                break;
        }

        g2.drawImage(image, x-100, y-110, 250, 250, null);

    }
}
