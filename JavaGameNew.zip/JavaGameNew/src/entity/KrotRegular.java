package entity;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

import main.GamePanel;

public class KrotRegular extends Entity {
    GamePanel gp;
    private long spawnTime;
    private long destroyTime;
    private BufferedImage[] animationFrames;
    private int currentFrame = 0;
    private int frameDelay = 10;
    private int frameCounter = 0;
    private boolean isDestroyed = false;

    public KrotRegular(GamePanel gp) {
        this.gp = gp;
        loadAnimationFrames();
        spawnAtRandomLocation();
        setRandomLifetime();
    }

    private void loadAnimationFrames() {
        try {
            animationFrames = new BufferedImage[7];
            animationFrames[0] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotPopUp0.png"));
            animationFrames[1] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotPopUp1.png"));
            animationFrames[2] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotPopUp2.png"));
            animationFrames[3] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotPopUp3.png"));
            animationFrames[4] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotPopUp4.png"));
            animationFrames[5] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotPopUp5.png"));
            animationFrames[6] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotPopUp6.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void spawnAtRandomLocation() {
        Random random = new Random();
        x = random.nextInt(gp.screenWidth - gp.tileSize);
        y = random.nextInt(gp.screenHeight - gp.tileSize);
    }

    private void setRandomLifetime() {
        Random random = new Random();
        int lifetime = 3000 + random.nextInt(2001);
        spawnTime = System.currentTimeMillis();
        destroyTime = spawnTime + lifetime;
    }

    public void update() {
        if (System.currentTimeMillis() > destroyTime) {
            isDestroyed = true;
        }

        //animation
        if (!isDestroyed && currentFrame < animationFrames.length - 1) {
            frameCounter++;
            if (frameCounter > frameDelay) {
                currentFrame++;
                frameCounter = 0;
            }
        }
    }

    public void setDestroyed(boolean destroyed) {
        this.isDestroyed = destroyed;
    }



    public void draw(Graphics2D g2) {
        if (!isDestroyed) {
            g2.drawImage(animationFrames[currentFrame], x, y, gp.tileSize+50, gp.tileSize+50, null);
        }
    }


    public boolean isDestroyed() {
        return isDestroyed;
    }
}