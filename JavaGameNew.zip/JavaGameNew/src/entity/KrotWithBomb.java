package entity;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.Sound;

public class KrotWithBomb extends Entity {
    GamePanel gp;
    private long spawnTime;
    private long destroyTime;
    private BufferedImage[] animationFrames;
    public int currentFrame = 0;
    private int frameDelay = 10;
    private int frameCounter = 0;
    private boolean isDestroyed = false;
    public KrotWithBomb krotWothBomb;

    private Sound bombExplosionSound;

    int explosionPlayed = 0;

    public KrotWithBomb(GamePanel gp) {
        this.gp = gp;
        loadAnimationFrames();
        spawnAtRandomLocation();
        setRandomLifetime();

        bombExplosionSound = new Sound();
        bombExplosionSound.loadAndPrepareClip("/Sounds/explosion.wav");

    }

    private void loadAnimationFrames() {
        try {

            animationFrames = new BufferedImage[13];
            animationFrames[0] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotPopUp0.png"));
            animationFrames[1] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotPopUp1.png"));
            animationFrames[2] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotPopUp2.png"));
            animationFrames[3] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotWithBomb0.png"));
            animationFrames[4] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotWithBomb1.png"));
            animationFrames[5] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotWithBomb2.png"));
            animationFrames[6] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotWithBomb3.png"));
            animationFrames[7] = ImageIO.read(getClass().getResourceAsStream("/Krot/KrotWithBomb4.png"));
            animationFrames[8] = ImageIO.read(getClass().getResourceAsStream("/Explosion/Explosion1.png"));
            animationFrames[9] = ImageIO.read(getClass().getResourceAsStream("/Explosion/Explosion2.png"));
            animationFrames[10] = ImageIO.read(getClass().getResourceAsStream("/Explosion/Explosion3.png"));
            animationFrames[11] = ImageIO.read(getClass().getResourceAsStream("/Explosion/Explosion4.png"));
            animationFrames[12] = ImageIO.read(getClass().getResourceAsStream("/Explosion/Explosion5.png"));


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void spawnAtRandomLocation() {
        Random random = new Random();
        x = random.nextInt(gp.screenWidth - gp.tileSize - 40);
        y = random.nextInt(gp.screenHeight - gp.tileSize - 40);
    }

    private void setRandomLifetime() {
        //Random random = new Random();
        int lifetime = 2500; //  + random.nextInt(2001);
        spawnTime = System.currentTimeMillis();
        destroyTime = spawnTime + lifetime;
    }

    public void triggerExplosion() {
        currentFrame = 9; //Explosion0
        frameCounter = 0;
        //isDestroyed = true;

    }

    public void update() {
        if (System.currentTimeMillis() > destroyTime) {
            isDestroyed = true;

        }

        //animate frames if not destroyed
        if (!isDestroyed && currentFrame < animationFrames.length - 1) {
            frameCounter++;
            if (frameCounter > frameDelay) {
                currentFrame++;
                frameCounter = 0;
            }
            if (currentFrame == 9 && explosionPlayed == 0){
                bombExplosionSound.playLoadedClip();
                explosionPlayed = 1;
            }
        }
    }

    public void setDestroyed(boolean destroyed) {
        this.isDestroyed = destroyed;
    }

    public void draw(Graphics2D g2) {
        if (!isDestroyed) {
            g2.drawImage(animationFrames[currentFrame], x, y, gp.tileSize+50, gp.tileSize+50, null);
        }
    }


    public boolean isDestroyed() {
        return isDestroyed;
    }
}