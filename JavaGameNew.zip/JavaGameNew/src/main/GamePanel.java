package main;

import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import javax.swing.JPanel;

import entity.Entity;
import entity.Hummer;
import entity.Player;
import entity.KrotRegular;
import entity.KrotWithBomb;



public class GamePanel extends JPanel implements Runnable {


    // Screen settings
    final int originalTileSize = 16;
    final int scale = 3;

    public final int tileSize = originalTileSize * scale; // 48x48
    final int maxScreenCol = 16;
    final int maxScreenRow = 12;
    public final int screenWidth = tileSize * maxScreenCol; // 768
    public final int screenHeight = tileSize * maxScreenRow; // 576

    // FPS
    int FPS = 60;

    KeyHandler keyH;
    Thread gameThread;
    Player player;
    Hummer hummer;
    public KrotRegular krotRegular;
    public KrotWithBomb krotWithBomb;

    //sounds
    private Sound bombExplosionSound;
    private Sound smashSound;
    private Sound gameOverSound;
    private Sound music;


    //krot management
    private ArrayList<Object> krotList = new ArrayList<>();
    private long nextSpawnTime = 0;

    //other
    private boolean isPlayerActive = true;
    private boolean isHummerActive = true;
    int destroyPlayed = 0;

    //score
    private int score = 0;

    //game state
    public String gameState = "start";

    //font
    private Font customFont;


    public GamePanel() {

        //font
        try {
            InputStream fontStream = getClass().getResourceAsStream("/Font/Daydream.ttf");

            if (fontStream != null) {
                customFont = Font.createFont(Font.TRUETYPE_FONT, fontStream).deriveFont(25f);
            } else {
                throw new Exception("font not found");
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("fail to load custom font");
            customFont = new Font("Arial", Font.PLAIN, 25);
        }



        keyH = new KeyHandler(this);
        this.addKeyListener(keyH);
        System.out.println("KeyHandler added to the GamePanel.");


        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (gameState.equals("start") && e.getKeyCode() == KeyEvent.VK_ENTER) {
                    System.out.println("Enter pressed in GamePanel");
                    gameState = "play";
                    restartGame();
                }
            }
        });

        this.setPreferredSize(new Dimension(screenWidth, screenHeight));
        this.setBackground(Color.white);
        this.setDoubleBuffered(true);



        keyH = new KeyHandler(this);
        player = new Player(this, keyH);
        hummer = new Hummer(this, keyH);

        this.addKeyListener(keyH);
        this.setFocusable(true);


        bombExplosionSound = new Sound();
        bombExplosionSound.loadAndPrepareClip("/Sounds/explosion.wav");

        smashSound = new Sound();
        smashSound.loadAndPrepareClip("/Sounds/hit.wav");

        gameOverSound = new Sound();
        gameOverSound.loadAndPrepareClip("/Sounds/GameOver.wav");

        music = new Sound();
        music.loadAndPrepareClip("/Sounds/Music.wav");


        this.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                System.out.println("GamePanel gained focus");
            }

            @Override
            public void focusLost(FocusEvent e) {
                System.out.println("GamePanel lost focus");
            }
        });

        this.setFocusable(true);
        this.requestFocusInWindow();
    }

    public void startGameThread() {
        gameThread = new Thread(this);
        gameThread.start();
        music.loopLoadedClip();
    }



    private static final int SLEEP_DURATION_MS = 2;

    @Override
    public void run() {
        System.out.println("game loop started");
        double drawInterval = 1000000000 / FPS;
        long lastTime = System.nanoTime();
        long currentTime;

        while (gameThread != null) {
            System.out.println("game loop running");
            currentTime = System.nanoTime();
            double delta = (currentTime - lastTime) / drawInterval;

            if (delta >= 1) {
                update();
                repaint();
                lastTime = currentTime;
            }

            try {
                Thread.sleep(SLEEP_DURATION_MS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void restartGame() {
        //reset
        isPlayerActive = true;
        isHummerActive = true;


        player.setDefaultValues();
        hummer.setDefaultValues();


        krotList.clear();
        nextSpawnTime = 0;


        score = 0;
        gameState = "play";

        destroyPlayed = 0;
        music.loopLoadedClip();
    }

    public void drawStartScreen(Graphics2D g2) {
        g2.setColor(Color.WHITE);
        g2.fillRect(0, 0, screenWidth, screenHeight);

        g2.setColor(Color.RED);

        Font largeFont = customFont.deriveFont(35f);
        g2.setFont(largeFont);
        g2.drawString("MOLESMASHER",180, 100);

        g2.setColor(Color.BLACK);
        g2.setFont(customFont);

        String[] lines = {
                "",
                "Press Enter to Start",
                " ",
                "Space - Smash",
                "WASD - Move",
                " ",
                "Smash all the moles!",
                "But be careful,",
                "some of them have a bomb!"
        };

        int lineHeight = g2.getFontMetrics().getHeight();
        int totalHeight = lines.length * lineHeight;
        int startY = (screenHeight - totalHeight) / 2;

        for (int i = 0; i < lines.length; i++) {
            int textWidth = g2.getFontMetrics().stringWidth(lines[i]);
            int x = (screenWidth - textWidth) / 2;
            int y = startY + (i * lineHeight);
            g2.drawString(lines[i], x, y);
        }
    }

    public void update() {

        if (gameState.equals("start")) {
            System.out.println("start state");
            if (keyH.enterPressed) {
                System.out.println("enter key to start the game pressed");
                gameState = "play";
                restartGame();
            }
        }

        System.out.println("game state: " + gameState);

        System.out.println("Game update");
        if (isPlayerActive && player != null) {
            player.update();
        }

        if (isHummerActive && hummer != null) {
            hummer.update();
        }

        if (gameState.equals("start") && keyH.enterPressed) {
            gameState = "play";
            restartGame();
        }


        Iterator<Object> iterator = krotList.iterator();
        while (iterator.hasNext()) {
            Object krot = iterator.next();
            if (krot instanceof KrotRegular) {
                KrotRegular regular = (KrotRegular) krot;
                regular.update();

                if (isColliding(hummer, regular) && isHummerSmashing()) {
                    regular.setDestroyed(true);
                    iterator.remove();
                    score++;
                }
            } else if (krot instanceof KrotWithBomb) {
                KrotWithBomb bomb = (KrotWithBomb) krot;
                bomb.update();


                if (isColliding(hummer, bomb) && isHummerSmashing() && !bomb.isDestroyed()) {
                    bomb.triggerExplosion();
                    isPlayerActive = false;
                    isHummerActive = false;

                    if (destroyPlayed == 0) {
                        gameOverSound.playLoadedClip();
                        destroyPlayed = 1;
                    }
                }
            }
        }

        if (System.currentTimeMillis() > nextSpawnTime) {
            spawnRandomKrot();
        }



        //restart game
        if (!isPlayerActive && keyH.restartPressed) {
            restartGame();
        }
    }

    private boolean isColliding(Entity e1, Entity e2) {
        int e1Left = e1.x - 50;
        int e1Right = e1.x + tileSize + 40;
        int e1Top = e1.y - 40;
        int e1Bottom = e1.y + tileSize + 40;

        int e2Left = e2.x;
        int e2Right = e2.x + tileSize;
        int e2Top = e2.y;
        int e2Bottom = e2.y + tileSize;

        return e1Right > e2Left && e1Left < e2Right && e1Bottom > e2Top && e1Top < e2Bottom;
    }

    private boolean isHummerSmashing() {
        return keyH.spacePressed;
    }

    public void spawnRandomKrot() {
        Random random = new Random();
        Object krot;

        System.out.println("spawning krot");

        if (random.nextInt(100) < 70) {
            krot = new KrotRegular(this);
        } else {
            krot = new KrotWithBomb(this);
        }

        krotList.add(krot);
        nextSpawnTime = System.currentTimeMillis() + 1000 + random.nextInt(1001);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        System.out.println("repaint");

        if (gameState.equals("start")) {
            drawStartScreen(g2);
        } else if (gameState.equals("play")) {
            if (isPlayerActive && isHummerActive) {
                player.draw(g2);
                hummer.draw(g2);
            }

            for (Object krot : krotList) {
                if (krot instanceof KrotRegular) {
                    ((KrotRegular) krot).draw(g2);
                } else if (krot instanceof KrotWithBomb) {
                    ((KrotWithBomb) krot).draw(g2);
                }
            }

            g2.setColor(Color.BLACK);
            g2.setFont(customFont);
            g2.drawString("Score: " + score, 10, 30);
        }

        if (!isPlayerActive) {
            music.stopLoadedClip();
            g2.setColor(Color.BLACK);
            Font smallFont = customFont.deriveFont(20f);
            g2.setFont(smallFont);
            g2.drawString("Game Over! Press 'R' to Restart", 105, 300);
        }
    }
}