package main;

import javax.swing.JFrame;

public class Main {

    public static void main(String[] args) {

        JFrame window = new JFrame();
        GamePanel gp = new GamePanel();
        KeyHandler keyH = new KeyHandler(gp);

        gp.addKeyListener(keyH);
        gp.setFocusable(true);

        window.add(gp);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.pack();
        window.setLocationRelativeTo(null);
        window.setVisible(true);


        gp.startGameThread();

        gp.requestFocusInWindow();


    }



}




