package main;

import javax.sound.sampled.*;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.IOException;

public class Sound {
    private Clip clip;

    public Clip loadAndPrepareClip(String path) {
        clip = prepareAudioClip(path);
        return clip;
    }

    private Clip prepareAudioClip(String path) {
        try {
            InputStream audioSource = getClass().getResourceAsStream(path);
            if (audioSource == null) {
                System.out.println("sound not found, file: " + path);
                return null;
            }
            BufferedInputStream bufferedIn = new BufferedInputStream(audioSource);
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(bufferedIn);
            Clip newClip = AudioSystem.getClip();
            newClip.open(audioStream);
            return newClip;
        } catch (IOException | UnsupportedAudioFileException | LineUnavailableException e) {
            System.out.println("error preparing audio: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    private boolean isClipValid() {
        if (clip == null) {
            System.out.println("no loaded clip");
            return false;
        }
        return true;
    }

    public void playLoadedClip() {
        if (isClipValid()) {
            clip.setFramePosition(0);
            clip.start();
        }
    }

    public void loopLoadedClip() {
        if (isClipValid()) {
            clip.loop(Clip.LOOP_CONTINUOUSLY);
        }
    }

    public void stopLoadedClip() {
        if (isClipValid()) {
            clip.stop();
        }
    }
}